#include <Wire.h>
#include "imu_control.h"
#include <math.h>

// ไม่ต้องเรียก Library MPU6050 แล้วเพราะเราจะปลอมค่า
OrientationData imu_data;
unsigned long lastTime = 0;

void initIMU() {
    // บังคับให้เริ่ม Serial1 เพื่อแจ้งเตือน
    Serial1.println("--- IMU FAKE MODE ACTIVATED ---");
    Serial1.println("Warning: MPU6050 hardware check bypassed.");
    
    // ตั้งค่าเริ่มต้นเป็น 0 ให้หมด
    imu_data.yaw = 0.0f;
    imu_data.pitch = 0.0f;
    imu_data.roll = 0.0f;
    imu_data.accX = 0.0f;
    imu_data.accY = 0.0f;
    imu_data.accZ = 0.0f;

    lastTime = millis();
    Serial1.println("Fake IMU Ready!");
}

void updateIMU() {
    // ไม่ต้องอ่านค่าจาก Hardware จริง
    // ปลอมค่าให้เป็น 0 ตลอดเวลา เพื่อให้ Main Loop ทำงานต่อได้
    imu_data.yaw = 0.0f;
    imu_data.pitch = 0.0f;
    imu_data.roll = 0.0f;
    
    imu_data.accX = 0.0f;
    imu_data.accY = 0.0f;
    imu_data.accZ = 0.0f;
    
    // อัปเดตเวลาเพื่อให้ dt ไม่ค้าง (เผื่อมีคนเอาไปคำนวณต่อ)
    lastTime = millis();
}
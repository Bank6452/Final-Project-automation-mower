#ifndef IMU_CONTROL_H
#define IMU_CONTROL_H

#include <Arduino.h>

struct OrientationData {
    float yaw, pitch, roll;
    float accX, accY, accZ; // เพิ่มเพื่อเก็บค่าแรงสั่น
    uint8_t sys, gyro, accel, mag;
};

extern OrientationData imu_data;

void initIMU();
void updateIMU();

#endif